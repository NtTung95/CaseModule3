create definer = root@localhost view orderhistory_view as
select `mikencobrand`.`orders`.`customerID`                                         AS `customerID`,
       `mikencobrand`.`orders`.`orderId`                                            AS `orderId`,
       `mikencobrand`.`product`.`productName`                                       AS `productName`,
       `mikencobrand`.`product`.`price`                                             AS `price`,
       `mikencobrand`.`orderdetail`.`quantity`                                      AS `quantity`,
       `mikencobrand`.`orders`.`dateOrdered`                                        AS `dateOrdered`,
       (`mikencobrand`.`product`.`price` * `mikencobrand`.`orderdetail`.`quantity`) AS `total`
from ((`mikencobrand`.`orderdetail` join `mikencobrand`.`orders` on ((`mikencobrand`.`orderdetail`.`orderId` =
                                                                      `mikencobrand`.`orders`.`orderId`)))
         join `mikencobrand`.`product`
              on ((`mikencobrand`.`orderdetail`.`productId` = `mikencobrand`.`product`.`productId`)));

